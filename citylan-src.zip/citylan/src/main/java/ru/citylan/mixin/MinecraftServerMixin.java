package ru.citylan.mixin;

import net.minecraft.server.MinecraftServer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.citylan.LanState;

@Mixin(MinecraftServer.class)
public class MinecraftServerMixin {
    @Inject(method = "halt", at = @At("HEAD"), cancellable = true, require = 0)
    private void citylan$keepAlive(boolean wait, CallbackInfo ci) {
        if (LanState.keepAlive((MinecraftServer) (Object) this)) ci.cancel();
    }
}
