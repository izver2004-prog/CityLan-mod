package ru.citylan.mixin;

import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.citylan.client.CityLanScreen;

/** Кнопка CityLan в главном меню (чтобы управлять сервером, когда вышел из мира). */
@Mixin(TitleScreen.class)
public abstract class TitleScreenMixin extends Screen {
    protected TitleScreenMixin(Component title) { super(title); }

    @Inject(method = "init", at = @At("TAIL"), require = 0)
    private void citylan$button(CallbackInfo ci) {
        this.addRenderableWidget(Button.builder(Component.literal("CityLan"),
                b -> this.minecraft.gui.setScreen(new CityLanScreen(this))).bounds(4, 4, 70, 20).build());
    }
}
