package ru.citylan;

import net.minecraft.server.MinecraftServer;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/** Общее состояние нашего сервера (живёт, пока открыт Майнкрафт). */
public final class LanState {
    public static volatile MinecraftServer hostedServer;
    public static volatile boolean active, shuttingDown, ownerInWorld;
    public static volatile String name = "Мой сервер", description = "", password = "";
    public static volatile int maxPlayers = 4, port = 25565;
    public static volatile String netStatus = "";

    private static final long BAN_MS = 10 * 60_000L;
    private static final Map<String, Long> banned = new ConcurrentHashMap<>();
    private static final Map<String, Integer> fails = new ConcurrentHashMap<>();

    private LanState() {}

    /** Нужно ли не давать серверу остановиться (выход из мира, не из игры). */
    public static boolean keepAlive(MinecraftServer s) {
        return s == hostedServer && active && !shuttingDown;
    }

    public static boolean isBanned(String ip) {
        Long until = banned.get(ip);
        if (until == null) return false;
        if (System.currentTimeMillis() >= until) { banned.remove(ip); fails.remove(ip); return false; }
        return true;
    }

    /** @return true, если после этой ошибки IP забанен */
    public static boolean registerFail(String ip) {
        if (isLoopback(ip)) return false; // чтобы не забанить себя / туннель
        if (fails.merge(ip, 1, Integer::sum) >= 2) {
            banned.put(ip, System.currentTimeMillis() + BAN_MS);
            return true;
        }
        return false;
    }

    public static void success(String ip) { fails.remove(ip); }

    private static boolean isLoopback(String ip) {
        return ip.equals("127.0.0.1") || ip.equals("0:0:0:0:0:0:0:1") || ip.equals("::1");
    }
}
