package ru.citylan.client;

import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.StringWidget;
import net.minecraft.client.gui.screens.ConnectScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.multiplayer.resolver.ServerAddress;
import net.minecraft.client.server.IntegratedServer;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import ru.citylan.LanState;

import java.net.InetAddress;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.List;
import java.util.concurrent.CompletableFuture;

public class CityLanScreen extends Screen {
    private static volatile String publicIp = "определяю...";
    private final Screen parent;
    private EditBox nameBox, descBox, passBox, portBox;
    private Button maxBtn;
    private StringWidget statusLine, addrPublic, addrLocal;
    private int max = LanState.maxPlayers;
    private String error = "";

    public CityLanScreen(Screen parent) {
        super(Component.literal("CityLan"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        boolean on = LanState.active;
        int w = 220, x = width / 2 - w / 2, y = 20;
        addRenderableWidget(new StringWidget(x, y, w, 12, Component.literal("CityLan — свой сервер"), font));
        y += 18;
        nameBox = box(x, y, w, "Название", LanState.name, 40, on); y += 24;
        descBox = box(x, y, w, "Описание", LanState.description, 60, on); y += 24;
        passBox = box(x, y, w, "Пароль (пусто = без пароля)", LanState.password, 32, on); y += 24;
        portBox = box(x, y, w, "Порт", String.valueOf(LanState.port), 5, on); y += 24;

        maxBtn = addRenderableWidget(Button.builder(maxText(), b -> {
            max = max >= 8 ? 2 : max + 1;
            b.setMessage(maxText());
        }).bounds(x, y, w, 20).build());
        maxBtn.active = !on;
        y += 24;

        addRenderableWidget(Button.builder(
                Component.literal(on ? "Остановить сервер" : "Создать сервер"), b -> toggle())
                .bounds(x, y, w, 20).build());
        y += 24;

        if (on && minecraft.level == null) {
            addRenderableWidget(Button.builder(Component.literal("Зайти на свой сервер"), b -> joinOwn())
                    .bounds(x, y, w, 20).build());
            y += 24;
        }

        statusLine = addRenderableWidget(new StringWidget(x, y, w, 12, Component.empty(), font)); y += 13;
        addrPublic = addRenderableWidget(new StringWidget(x, y, w, 12, Component.empty(), font)); y += 13;
        addrLocal = addRenderableWidget(new StringWidget(x, y, w, 12, Component.empty(), font));

        addRenderableWidget(Button.builder(CommonComponents.GUI_DONE, b -> onClose())
                .bounds(x, height - 26, w, 20).build());
    }

    private EditBox box(int x, int y, int w, String label, String value, int maxLen, boolean locked) {
        EditBox b = new EditBox(font, x, y, w, 20, Component.literal(label));
        b.setHint(Component.literal(label));
        b.setMaxLength(maxLen);
        b.setValue(value);
        b.setEditable(!locked);
        return addRenderableWidget(b);
    }

    private Component maxText() { return Component.literal("Макс. игроков: " + max); }

    @Override
    public void tick() {
        MinecraftServer s = LanState.hostedServer;
        String st;
        if (!error.isEmpty()) st = error;
        else if (!LanState.active) st = "Сервер выключен";
        else st = "Работает • игроков " + (s == null ? 0 : s.getPlayerList().getPlayerCount())
                + "/" + LanState.maxPlayers + (LanState.password.isEmpty() ? "" : " • пароль");
        statusLine.setMessage(Component.literal(st));
        if (LanState.active) {
            addrPublic.setMessage(Component.literal("Для друзей: " + publicIp + ":" + LanState.port));
            addrLocal.setMessage(Component.literal("В одной сети: " + localIp() + ":" + LanState.port));
        } else {
            addrPublic.setMessage(Component.empty());
            addrLocal.setMessage(Component.empty());
        }
    }

    private void saveFields() {
        LanState.name = nameBox.getValue().isBlank() ? "Мой сервер" : nameBox.getValue().trim();
        LanState.description = descBox.getValue().trim();
        LanState.password = passBox.getValue();
        LanState.maxPlayers = max;
        try { LanState.port = Integer.parseInt(portBox.getValue().trim()); } catch (NumberFormatException e) { LanState.port = 25565; }
    }

    private void toggle() {
        error = "";
        if (LanState.active) stopServer(); else startServer();
        if (error.isEmpty() || LanState.active) rebuildWidgets();
    }

    private void startServer() {
        saveFields();
        IntegratedServer s = minecraft.getSingleplayerServer();
        if (s == null) { error = "Сначала откройте одиночный мир"; return; }
        if (LanState.port < 1024 || LanState.port > 65535) { error = "Порт должен быть 1024–65535"; return; }
        if (!s.isPublished() && !s.publishServer(s.getDefaultGameType(), false, LanState.port)) {
            error = "Не удалось открыть порт " + LanState.port; return;
        }
        LanState.port = s.getPort();
        s.setMotd(LanState.name + (LanState.description.isEmpty() ? "" : " | " + LanState.description));
        LanState.hostedServer = s;
        LanState.shuttingDown = false;
        LanState.active = true;
        fetchPublicIp();
    }

    private void stopServer() {
        LanState.active = false;
        MinecraftServer s = LanState.hostedServer;
        if (s == null) return;
        var me = minecraft.getUser().getProfileId();
        for (ServerPlayer p : List.copyOf(s.getPlayerList().getPlayers())) {
            if (!p.getUUID().equals(me)) p.connection.disconnect(Component.literal("Сервер остановлен"));
        }
        if (minecraft.getSingleplayerServer() != s) { // «осиротевший» сервер — гасим сами
            LanState.shuttingDown = true;
            new Thread(() -> {
                try { s.halt(true); } catch (Throwable ignored) {}
                LanState.hostedServer = null;
                LanState.shuttingDown = false;
            }, "citylan-stop").start();
        }
    }

    private void joinOwn() {
        String addr = "localhost:" + LanState.port;
        ConnectScreen.startConnecting(this, minecraft, ServerAddress.parseString(addr),
                new ServerData(LanState.name, addr, ServerData.Type.OTHER), false, null);
    }

    private static void fetchPublicIp() {
        publicIp = "определяю...";
        CompletableFuture.runAsync(() -> {
            try {
                var r = HttpClient.newHttpClient().send(
                        HttpRequest.newBuilder(URI.create("https://api.ipify.org")).timeout(Duration.ofSeconds(5)).build(),
                        HttpResponse.BodyHandlers.ofString());
                publicIp = r.body().trim();
            } catch (Exception e) { publicIp = "не удалось определить"; }
        });
    }

    private static String localIp() {
        try { return InetAddress.getLocalHost().getHostAddress(); } catch (Exception e) { return "?"; }
    }

    @Override public boolean isPauseScreen() { return false; } // сервер не ставим на паузу
    @Override public void onClose() { minecraft.setScreen(parent); }
}
