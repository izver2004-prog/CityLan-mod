package ru.citylan.client;

import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.StringWidget;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.function.Consumer;

public class PasswordScreen extends Screen {
    private final Consumer<String> onSubmit;
    private final Runnable onCancel;
    private EditBox box;
    private boolean done;

    public PasswordScreen(Consumer<String> onSubmit, Runnable onCancel) {
        super(Component.literal("Пароль"));
        this.onSubmit = onSubmit;
        this.onCancel = onCancel;
    }

    @Override
    protected void init() {
        int w = 200, x = width / 2 - w / 2, y = height / 2 - 30;
        addRenderableWidget(new StringWidget(x, y, w, 12, Component.literal("Введите пароль сервера"), font));
        box = new EditBox(font, x, y + 18, w, 20, Component.literal("Пароль"));
        box.setMaxLength(128);
        addRenderableWidget(box);
        setInitialFocus(box);
        addRenderableWidget(Button.builder(Component.literal("Войти"), b -> submit())
                .bounds(x, y + 46, 98, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Отмена"), b -> onClose())
                .bounds(x + 102, y + 46, 98, 20).build());
    }

    private void submit() {
        if (done) return;
        done = true;
        onSubmit.accept(box.getValue());
    }

    @Override
    public void onClose() {
        if (done) return;
        done = true;
        onCancel.run();
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
