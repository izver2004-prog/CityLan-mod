package ru.citylan.client;

import com.mojang.blaze3d.platform.InputConstants;
import io.netty.buffer.Unpooled;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientLoginNetworking;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.Identifier;
import ru.citylan.CityLan;
import ru.citylan.LanState;

import java.util.concurrent.CompletableFuture;

public class CityLanClient implements ClientModInitializer {
    private static KeyMapping open;

    @Override
    public void onInitializeClient() {
        KeyMapping.Category cat = KeyMapping.Category.register(Identifier.fromNamespaceAndPath(CityLan.MOD_ID, "main"));
        open = KeyMappingHelper.registerKeyMapping(
                new KeyMapping("key.citylan.open", InputConstants.KEY_N, cat));

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (open.consumeClick()) {
                if (mc.gui.screen() == null) mc.gui.setScreen(new CityLanScreen(null));
            }
        });

        // Сервер просит пароль (до входа в мир)
        ClientLoginNetworking.registerGlobalReceiver(CityLan.AUTH, (mc, handler, buf, listenerAdder) -> {
            CompletableFuture<FriendlyByteBuf> f = new CompletableFuture<>();
            mc.execute(() -> {
                Screen prev = mc.gui.screen();
                mc.gui.setScreen(new PasswordScreen(pass -> {
                    FriendlyByteBuf out = new FriendlyByteBuf(Unpooled.buffer());
                    out.writeUtf(pass, 128);
                    mc.gui.setScreen(prev);
                    f.complete(out);
                }, () -> {
                    mc.gui.setScreen(prev);
                    f.complete(null);
                }));
            });
            return f;
        });

        ClientPlayConnectionEvents.JOIN.register((h, s, mc) -> LanState.ownerInWorld = mc.getSingleplayerServer() != null);
        ClientPlayConnectionEvents.DISCONNECT.register((h, mc) -> LanState.ownerInWorld = false);

        // Закрыли Майнкрафт целиком — сервер гасим
        ClientLifecycleEvents.CLIENT_STOPPING.register(mc -> {
            LanState.active = false;
            LanState.shuttingDown = true;
            var s = LanState.hostedServer;
            if (s != null && mc.getSingleplayerServer() != s) {
                try { s.halt(true); } catch (Throwable ignored) {}
            }
        });

    }
}
