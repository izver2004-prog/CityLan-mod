package ru.citylan;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilderFactory;
import java.io.ByteArrayInputStream;
import java.net.*;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Locale;

/** Автоматически открывает порт на роутере (UPnP IGD). Без внешних библиотек. */
public final class Upnp {
    public static volatile String externalIp;
    private static String controlUrl, serviceType, localIp;
    private static int mappedPort = -1;
    private static final HttpClient HTTP = HttpClient.newBuilder()
            .version(HttpClient.Version.HTTP_1_1).connectTimeout(Duration.ofSeconds(3)).build();

    private Upnp() {}

    /** @return внешний IP роутера (может быть null) */
    public static synchronized String open(int port, String description) throws Exception {
        discover();
        soap("AddPortMapping",
                "<NewRemoteHost></NewRemoteHost><NewExternalPort>" + port + "</NewExternalPort>"
                + "<NewProtocol>TCP</NewProtocol><NewInternalPort>" + port + "</NewInternalPort>"
                + "<NewInternalClient>" + localIp + "</NewInternalClient><NewEnabled>1</NewEnabled>"
                + "<NewPortMappingDescription>" + description.replaceAll("[<>&]", "") + "</NewPortMappingDescription>"
                + "<NewLeaseDuration>0</NewLeaseDuration>");
        mappedPort = port;
        externalIp = null;
        try {
            String r = soap("GetExternalIPAddress", "");
            int a = r.indexOf("<NewExternalIPAddress>"), b = r.indexOf("</NewExternalIPAddress>");
            if (a >= 0 && b > a) externalIp = r.substring(a + 22, b).trim();
        } catch (Exception ignored) {}
        return externalIp;
    }

    /** Закрыть порт на роутере (безопасно вызывать много раз). */
    public static synchronized void close() {
        if (mappedPort < 0 || controlUrl == null) return;
        try {
            soap("DeletePortMapping", "<NewRemoteHost></NewRemoteHost><NewExternalPort>" + mappedPort
                    + "</NewExternalPort><NewProtocol>TCP</NewProtocol>");
        } catch (Exception ignored) {}
        mappedPort = -1;
    }

    public static boolean isPrivate(String ip) {
        if (ip == null) return false;
        return ip.startsWith("10.") || ip.startsWith("192.168.") || ip.matches("172\\.(1[6-9]|2\\d|3[01])\\..*")
                || ip.matches("100\\.(6[4-9]|[7-9]\\d|1[01]\\d|12[0-7])\\..*");
    }

    private static void discover() throws Exception {
        String msg = "M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\nMAN: \"ssdp:discover\"\r\nMX: 2\r\n"
                + "ST: urn:schemas-upnp-org:device:InternetGatewayDevice:1\r\n\r\n";
        byte[] out = msg.getBytes(StandardCharsets.UTF_8);
        try (DatagramSocket s = new DatagramSocket()) {
            s.setSoTimeout(1000);
            s.send(new DatagramPacket(out, out.length, InetAddress.getByName("239.255.255.250"), 1900));
            long end = System.currentTimeMillis() + 4000;
            while (System.currentTimeMillis() < end) {
                DatagramPacket p = new DatagramPacket(new byte[2048], 2048);
                try { s.receive(p); } catch (SocketTimeoutException e) { continue; }
                String resp = new String(p.getData(), 0, p.getLength(), StandardCharsets.UTF_8);
                for (String line : resp.split("\r\n")) {
                    if (line.toLowerCase(Locale.ROOT).startsWith("location:")) {
                        try { if (describe(line.substring(9).trim())) return; } catch (Exception ignored) {}
                    }
                }
            }
        }
        throw new IllegalStateException("роутер не отвечает на UPnP");
    }

    private static boolean describe(String location) throws Exception {
        URI loc = URI.create(location);
        HttpResponse<byte[]> r = HTTP.send(HttpRequest.newBuilder(loc).timeout(Duration.ofSeconds(4)).build(),
                HttpResponse.BodyHandlers.ofByteArray());
        Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder()
                .parse(new ByteArrayInputStream(r.body()));
        NodeList services = doc.getElementsByTagName("service");
        for (int i = 0; i < services.getLength(); i++) {
            Element e = (Element) services.item(i);
            String type = text(e, "serviceType");
            if (type != null && (type.contains("WANIPConnection") || type.contains("WANPPPConnection"))) {
                serviceType = type.trim();
                controlUrl = loc.resolve(text(e, "controlURL").trim()).toString();
                try (Socket sock = new Socket()) {
                    sock.connect(new InetSocketAddress(loc.getHost(), loc.getPort() > 0 ? loc.getPort() : 80), 2000);
                    localIp = sock.getLocalAddress().getHostAddress();
                }
                return true;
            }
        }
        return false;
    }

    private static String text(Element e, String tag) {
        NodeList n = e.getElementsByTagName(tag);
        return n.getLength() == 0 ? null : n.item(0).getTextContent();
    }

    private static String soap(String action, String args) throws Exception {
        String body = "<?xml version=\"1.0\"?><s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\" "
                + "s:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\"><s:Body><u:" + action
                + " xmlns:u=\"" + serviceType + "\">" + args + "</u:" + action + "></s:Body></s:Envelope>";
        HttpResponse<String> r = HTTP.send(HttpRequest.newBuilder(URI.create(controlUrl))
                .timeout(Duration.ofSeconds(5))
                .header("Content-Type", "text/xml; charset=\"utf-8\"")
                .header("SOAPAction", "\"" + serviceType + "#" + action + "\"")
                .POST(HttpRequest.BodyPublishers.ofString(body)).build(), HttpResponse.BodyHandlers.ofString());
        if (r.statusCode() != 200) throw new IllegalStateException(action + ": роутер ответил " + r.statusCode());
        return r.body();
    }
}
