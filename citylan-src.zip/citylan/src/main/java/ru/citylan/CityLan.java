package ru.citylan;

import io.netty.buffer.Unpooled;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerLoginConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerLoginNetworking;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.server.network.ServerLoginPacketListenerImpl;
import net.minecraft.server.players.PlayerList;
import ru.citylan.mixin.LoginAccessor;

import java.net.InetSocketAddress;

public class CityLan implements ModInitializer {
    public static final String MOD_ID = "citylan";
    public static final Identifier AUTH = Identifier.fromNamespaceAndPath(MOD_ID, "auth");

    @Override
    public void onInitialize() {
        // 1. Ещё до входа в мир: бан, лимит, запрос пароля
        ServerLoginConnectionEvents.QUERY_START.register((handler, server, sender, sync) -> {
            if (server != LanState.hostedServer) return;
            String ip = ip(handler);
            if (!LanState.active) { handler.disconnect(Component.literal("Сервер закрыт владельцем.")); return; }
            if (LanState.isBanned(ip)) {
                handler.disconnect(Component.literal("Ваш IP временно заблокирован (неверный пароль). Попробуйте позже."));
                return;
            }
            if (server.getPlayerList().getPlayerCount() >= LanState.maxPlayers) {
                handler.disconnect(Component.literal("Сервер заполнен."));
                return;
            }
            if (!LanState.password.isEmpty()) {
                sender.sendPacket(AUTH, new FriendlyByteBuf(Unpooled.buffer()));
            }
        });

        // 2. Проверка пароля
        ServerLoginNetworking.registerGlobalReceiver(AUTH, (server, handler, understood, buf, sync, sender) -> {
            if (server != LanState.hostedServer) return;
            String ip = ip(handler);
            if (!understood) {
                handler.disconnect(Component.literal("Нужен мод CityLan и ввод пароля."));
                return;
            }
            String given = buf.readUtf(128);
            if (given.equals(LanState.password)) { LanState.success(ip); return; }
            boolean banned = LanState.registerFail(ip);
            handler.disconnect(Component.literal(banned
                    ? "Неверный пароль. Бан на 10 минут."
                    : "Неверный пароль. Осталась 1 попытка."));
        });

        // 3. Экономия ресурсов: дальность прорисовки/симуляции по числу игроков
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (server != LanState.hostedServer || !LanState.active) return;
            if (server.getTickCount() % 200 != 0 || LanState.ownerInWorld) return;
            int n = server.getPlayerList().getPlayerCount();
            int view = n == 0 ? 2 : n <= 3 ? 8 : 10;
            int sim = n == 0 ? 2 : n <= 3 ? 6 : 8;
            PlayerList pl = server.getPlayerList();
            if (pl.getViewDistance() != view) pl.setViewDistance(view);
            if (pl.getSimulationDistance() != sim) pl.setSimulationDistance(sim);
        });
    }

    private static String ip(ServerLoginPacketListenerImpl h) {
        var addr = ((LoginAccessor) h).citylan$getConnection().getRemoteAddress();
        return addr instanceof InetSocketAddress i ? i.getAddress().getHostAddress() : String.valueOf(addr);
    }
}
